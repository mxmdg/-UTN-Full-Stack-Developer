function Registro(){
  return (
      <div>
        <form>
          <div>
            <label>Nombre</label>
            <input type="text" />
          </div>
          <div>
            <label>Apellido</label>
            <input type="text" />
          </div>
        </form>
      </div>
  );
    
}

export default Registro;
