//Componente tipo funcion
import Productos from "./Productos";

function Home() {
  return (
    <div>
      <div>Home</div>
      <div>Home</div>
      <Productos />
    </div>
  );
}

export default Home;
