function Detalle(){
  //useState
  //handleClick -> dentro de la funcion cambiar el estado
  const handleClick = ()=>{
    
  }
  return (
    <div>
      <h1>iPhone 13</h1>
      <p>$500000</p>
      <p>Celulares</p>
      <p>SKU: 312312312</p>
      <button onClick={handleClick}>Comprar</button>
    </div>
  );
}

export default Detalle;
