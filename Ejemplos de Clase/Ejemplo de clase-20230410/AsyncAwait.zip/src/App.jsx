import logo from "./logo.svg";
import "./App.css";
import Home from "./Home";
import Contador from "./Contador";
import Registro from './Registro'
import Detalle from "./Detalle";

function App() {
  return (
    <div className="App">
      App
      {/* <Detalle />
      <Registro />
      <Contador /> */}
      <Home />
    </div>
  );
}

export default App;
