// Obtener la referencia de todos los divs en una constante llamada "divs".
//Escriba aquí su código:

let divs = document.querySelectorAll("div");

/*
Al obtener la referencia de los divs, usted podrá iterar estos mismos contenedores con métodos de javascript, cómo while o for.
*/

//Paso 1: recorra todos los divs del document.
//Paso 2: En cada iteración usted tendrá que agregarle el texto "box" a cada una de las cajas, dejando como resultado "box 1", "box 2" y "box 3"
//Pista: repasar la propiedad innerText
//Paso 3: Con la propiedad "style" pintar cada uno de las cajas de un color: box 1 en rojo, box 2 en verde, y box 3 en azul.
// Usted podría seleccionar cada elemento div, pero no tendría sentido si ya tenemos la referencia divs, aprovechar la iteración y realizar condicionales para obtener el resultado.
//Escriba aquí su código:

// Solución 1
/* for (let i = 0 ; i < divs.length ; i++) {
    divs[i].textContent = "box " + (i + 1);
    // let rgb = "#000";
    // rgb.replace(rgb[i+1],"f");  <- No funciona, reemplaza el caracter, no el index. Por lo tanto siempre reemplaza el primer '0'.
    let rgb = ["#f00", "#0f0" , "#00f"]; // Esta solución es más simple.
    divs[i].style.background = rgb[i];
} */

// Solución 2
/* for (let i = 0 ; i < divs.length ; i++) {
    divs[i].textContent = "box " + (i + 1);
    let rgb = "#123";
    let color = rgb.replace(rgb[i+1],"f"); // Funciona, siempre y cuando los caracteres de la cadena sean siempre distintos.
    console.log(color);
    divs[i].style.background = color;
} */

// Solución 3
for (let i = 0 ; i < divs.length ; i++) {
    divs[i].textContent = "Box " + (i + 1);
    let rgb = "#000";
    let color = rgb.slice(0,i+1) + "f" + rgb.slice(rgb.length - (rgb.length - i-2));  //Esta es la manera que encontré de reemplazar un caracter por su posición.
    divs[i].style.background = color;
}