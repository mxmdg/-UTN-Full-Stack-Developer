import Tablero from './Tablero.jsx';

function App() {
  return (
    <div className="App">
      <h1>Ejercico Tablero de Basquet</h1>
      <Tablero> Puntos del partido </Tablero>
    </div>
  );
}

export default App;
